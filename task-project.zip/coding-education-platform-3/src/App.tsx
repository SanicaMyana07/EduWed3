import { BrowserRouter as Router, Route, Switch } from "react-router-dom"
import { AuthProvider } from "./contexts/AuthContext"
import PrivateRoute from "./components/PrivateRoute"
import Navigation from "./components/Navigation"
import Dashboard from "./pages/Dashboard"
import Quiz from "./pages/Quiz"
import Practice from "./pages/Practice"
import CourseResources from "./pages/CourseResources"
import Community from "./pages/Community"
import Calendar from "./pages/Calendar"
import Login from "./pages/Login"
import "./styles/globals.css"

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Navigation />
          <Switch>
            <Route exact path="/login" component={Login} />
            <PrivateRoute exact path="/" component={Dashboard} />
            <PrivateRoute path="/quiz" component={Quiz} />
            <PrivateRoute path="/practice" component={Practice} />
            <PrivateRoute path="/resources" component={CourseResources} />
            <PrivateRoute path="/community" component={Community} />
            <PrivateRoute path="/calendar" component={Calendar} />
          </Switch>
        </div>
      </Router>
    </AuthProvider>
  )
}

export default App

