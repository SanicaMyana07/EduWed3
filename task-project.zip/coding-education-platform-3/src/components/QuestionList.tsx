import type React from "react"
import styled from "styled-components"

const ListContainer = styled.div`
  // Add your question list styling here
`

interface Question {
  id: string
  title: string
  difficulty: string
  // Add other question properties as needed
}

interface QuestionListProps {
  questions: Question[]
  onSelectQuestion: (question: Question) => void
}

const QuestionList: React.FC<QuestionListProps> = ({ questions, onSelectQuestion }) => {
  return (
    <ListContainer>
      <h2>Practice Questions</h2>
      {questions.map((question) => (
        <div key={question.id} onClick={() => onSelectQuestion(question)}>
          <h3>{question.title}</h3>
          <p>Difficulty: {question.difficulty}</p>
        </div>
      ))}
    </ListContainer>
  )
}

export default QuestionList

