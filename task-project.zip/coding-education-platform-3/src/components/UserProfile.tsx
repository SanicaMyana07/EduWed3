import styled from "styled-components"

const ProfileCard = styled.div`
  background-color: var(--color-white);
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`

const ProfileHeader = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
`

const ProfileAvatar = styled.img`
  width: 64px;
  height: 64px;
  border-radius: 50%;
  margin-right: 1rem;
`

const ProfileName = styled.h2`
  color: var(--color-primary);
  margin: 0;
`

const ProfileUsername = styled.p`
  color: var(--color-text-light);
  margin: 0;
`

const ProfileStats = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-top: 1rem;
`

const StatItem = styled.div`
  text-align: center;
`

const StatValue = styled.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: var(--color-secondary);
`

const StatLabel = styled.div`
  color: var(--color-text-light);
  font-size: 0.875rem;
`

const UserProfile = ({ userData, leetCodeInfo }) => {
  return (
    <ProfileCard>
      <ProfileHeader>
        <ProfileAvatar src={userData.avatarUrl} alt={userData.name} />
        <div>
          <ProfileName>{userData.name}</ProfileName>
          <ProfileUsername>@{userData.leetCodeUsername}</ProfileUsername>
        </div>
      </ProfileHeader>
      <ProfileStats>
        <StatItem>
          <StatValue>{leetCodeInfo.totalSolved}</StatValue>
          <StatLabel>Problems Solved</StatLabel>
        </StatItem>
        <StatItem>
          <StatValue>{userData.codeStreak}</StatValue>
          <StatLabel>Day Streak</StatLabel>
        </StatItem>
        <StatItem>
          <StatValue>{leetCodeInfo.ranking}</StatValue>
          <StatLabel>LeetCode Rank</StatLabel>
        </StatItem>
      </ProfileStats>
    </ProfileCard>
  )
}

export default UserProfile

