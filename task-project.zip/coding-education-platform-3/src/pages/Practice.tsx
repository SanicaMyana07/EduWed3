"use client"

import { useEffect, useState } from "react"
import { getLeetCodeQuestions } from "../services/leetCodeService"
import { getUserQuestionHistory } from "../services/firestoreService"
import QuestionList from "../components/QuestionList"
// import QuestionDetails from '../components/QuestionDetails';

const Practice = () => {
  const [questions, setQuestions] = useState([])
  const [userHistory, setUserHistory] = useState({})
  const [selectedQuestion, setSelectedQuestion] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      const questionsData = await getLeetCodeQuestions()
      setQuestions(questionsData)

      const historyData = await getUserQuestionHistory()
      setUserHistory(historyData)
    }

    fetchData()
  }, [])

  return (
    <div className="practice">
      <h1>Practice</h1>
      {selectedQuestion ? (
        <div>
          <h2>{selectedQuestion.title}</h2>
          <p>Difficulty: {selectedQuestion.difficulty}</p>
          {/* Implement question details view */}
        </div>
      ) : (
        <QuestionList questions={questions} onSelectQuestion={setSelectedQuestion} />
      )}
    </div>
  )
}

export default Practice

