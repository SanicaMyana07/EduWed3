"use client"

import type React from "react"
import { useState } from "react"
import styled from "styled-components"

const FormContainer = styled.form`
  // Add your form styling here
`

interface PostFormProps {
  onSubmit: (post: { title: string; content: string }) => void
}

const PostForm: React.FC<PostFormProps> = ({ onSubmit }) => {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({ title, content })
    setTitle("")
    setContent("")
  }

  return (
    <FormContainer onSubmit={handleSubmit}>
      <h2>Create a New Post</h2>
      <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Post Title" required />
      <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Post Content" required />
      <button type="submit">Submit Post</button>
    </FormContainer>
  )
}

export default PostForm

