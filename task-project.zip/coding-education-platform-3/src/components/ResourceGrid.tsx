import type React from "react"
import styled from "styled-components"

const GridContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
`

interface Resource {
  id: string
  title: string
  description: string
  url: string
  // Add other resource properties as needed
}

interface ResourceGridProps {
  resources: Resource[]
}

const ResourceGrid: React.FC<ResourceGridProps> = ({ resources }) => {
  return (
    <GridContainer>
      {resources.map((resource) => (
        <div key={resource.id}>
          <h3>{resource.title}</h3>
          <p>{resource.description}</p>
          <a href={resource.url} target="_blank" rel="noopener noreferrer">
            View Resource
          </a>
        </div>
      ))}
    </GridContainer>
  )
}

export default ResourceGrid

