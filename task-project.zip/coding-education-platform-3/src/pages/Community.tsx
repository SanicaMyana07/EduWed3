import { useEffect, useState } from "react"
import { getPosts, createPost, addComment } from "../services/firestoreService"
import PostList from "../components/PostList"
import PostForm from "../components/PostForm"

const Community = () => {
  const [posts, setPosts] = useState([])

  useEffect(() => {
    const fetchPosts = async () => {
      const postsData = await getPosts()
      setPosts(postsData)
    }

    fetchPosts()
  }, [])

  const handleCreatePost = async (postData) => {
    const newPost = await createPost(postData)
    setPosts([newPost, ...posts])
  }

  const handleAddComment = async (postId, commentData) => {
    const updatedPost = await addComment(postId, commentData)
    setPosts(posts.map((post) => (post.id === postId ? updatedPost : post)))
  }

  return (
    <div className="community">
      <h1>Community</h1>
      <PostForm onSubmit={handleCreatePost} />
      <PostList posts={posts} onAddComment={handleAddComment} />
    </div>
  )
}

export default Community

