"use client"

import type React from "react"
import styled from "styled-components"

const ListContainer = styled.div`
  display: grid;
  gap: 1rem;
`

const QuizItem = styled.div`
  background-color: var(--color-white);
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.2s ease-in-out;

  &:hover {
    transform: translateY(-2px);
  }
`

interface Quiz {
  id: string
  title: string
  description: string
  questionCount: number
}

interface QuizListProps {
  quizzes: Quiz[]
  onSelectQuiz: (quiz: Quiz) => void
}

const QuizList: React.FC<QuizListProps> = ({ quizzes, onSelectQuiz }) => {
  return (
    <ListContainer>
      {quizzes.map((quiz) => (
        <QuizItem key={quiz.id} onClick={() => onSelectQuiz(quiz)}>
          <h3>{quiz.title}</h3>
          <p>{quiz.description}</p>
          <small>{quiz.questionCount} questions</small>
        </QuizItem>
      ))}
    </ListContainer>
  )
}

export default QuizList

