import axios from "axios"

const LEETCODE_API_URL = "https://leetcode.com/api"

export const getUserLeetCodeInfo = async (username) => {
  try {
    const response = await axios.get(`${LEETCODE_API_URL}/users/${username}`)
    return response.data
  } catch (error) {
    console.error("Error fetching LeetCode user info:", error)
    return null
  }
}

export const getLeetCodeQuestions = async () => {
  try {
    const response = await axios.get(`${LEETCODE_API_URL}/problems/all/`)
    return response.data.stat_status_pairs
  } catch (error) {
    console.error("Error fetching LeetCode questions:", error)
    return []
  }
}

