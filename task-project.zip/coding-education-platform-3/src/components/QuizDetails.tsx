"use client"

import type React from "react"
import { useState } from "react"
import styled from "styled-components"

const QuizContainer = styled.div`
  background-color: var(--color-white);
  border-radius: 8px;
  padding: 2rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`

const Question = styled.div`
  margin-bottom: 1.5rem;
`

const OptionList = styled.div`
  display: grid;
  gap: 0.5rem;
`

const Option = styled.button<{ isSelected: boolean }>`
  background-color: ${(props) => (props.isSelected ? "var(--color-primary)" : "var(--color-background)")};
  color: ${(props) => (props.isSelected ? "var(--color-white)" : "var(--color-text)")};
  border: 1px solid var(--color-primary);
  border-radius: 4px;
  padding: 0.5rem 1rem;
  cursor: pointer;
  transition: all 0.2s ease-in-out;

  &:hover {
    background-color: var(--color-primary);
    color: var(--color-white);
  }
`

interface QuizQuestion {
  id: string
  question: string
  options: string[]
  correctAnswer: string
}

interface Quiz {
  id: string
  title: string
  description: string
  questions: QuizQuestion[]
}

interface QuizDetailsProps {
  quiz: Quiz
  onBack: () => void
}

const QuizDetails: React.FC<QuizDetailsProps> = ({ quiz, onBack }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: string]: string }>({})

  const currentQuestion = quiz.questions[currentQuestionIndex]

  const handleSelectOption = (option: string) => {
    setSelectedAnswers({ ...selectedAnswers, [currentQuestion.id]: option })
  }

  const handleNextQuestion = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const handleSubmit = () => {
    // Implement quiz submission logic here
    console.log("Quiz submitted:", selectedAnswers)
    onBack()
  }

  return (
    <QuizContainer>
      <h2>{quiz.title}</h2>
      <p>{quiz.description}</p>
      <Question>
        <h3>
          Question {currentQuestionIndex + 1} of {quiz.questions.length}
        </h3>
        <p>{currentQuestion.question}</p>
        <OptionList>
          {currentQuestion.options.map((option, index) => (
            <Option
              key={index}
              isSelected={selectedAnswers[currentQuestion.id] === option}
              onClick={() => handleSelectOption(option)}
            >
              {option}
            </Option>
          ))}
        </OptionList>
      </Question>
      <div>
        <button onClick={handlePreviousQuestion} disabled={currentQuestionIndex === 0}>
          Previous
        </button>
        {currentQuestionIndex === quiz.questions.length - 1 ? (
          <button onClick={handleSubmit}>Submit</button>
        ) : (
          <button onClick={handleNextQuestion}>Next</button>
        )}
      </div>
      <button onClick={onBack}>Back to Quiz List</button>
    </QuizContainer>
  )
}

export default QuizDetails

