import { useEffect, useState } from "react"
import { getCourseResources } from "../services/firestoreService"
import ResourceGrid from "../components/ResourceGrid"

const CourseResources = () => {
  const [resources, setResources] = useState([])

  useEffect(() => {
    const fetchResources = async () => {
      const resourcesData = await getCourseResources()
      setResources(resourcesData)
    }

    fetchResources()
  }, [])

  return (
    <div className="course-resources">
      <h1>Course Resources</h1>
      <ResourceGrid resources={resources} />
    </div>
  )
}

export default CourseResources

