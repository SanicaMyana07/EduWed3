"use client"

import type React from "react"
import { useEffect, useState } from "react"
import styled from "styled-components"
import { getQuizzes } from "../services/firestoreService"
import QuizList from "../components/QuizList"
import QuizDetails from "../components/QuizDetails"

const QuizContainer = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
`

interface Quiz {
  id: string
  title: string
  description: string
  questions: {
    id: string
    question: string
    options: string[]
    correctAnswer: string
  }[]
}

const Quiz: React.FC = () => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([])
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null)

  useEffect(() => {
    const fetchQuizzes = async () => {
      const quizzesData = await getQuizzes()
      setQuizzes(quizzesData)
    }

    fetchQuizzes()
  }, [])

  return (
    <QuizContainer>
      <h1>Quizzes</h1>
      {selectedQuiz ? (
        <QuizDetails quiz={selectedQuiz} onBack={() => setSelectedQuiz(null)} />
      ) : (
        <QuizList quizzes={quizzes} onSelectQuiz={(quiz) => setSelectedQuiz(quiz)} />
      )}
    </QuizContainer>
  )
}

export default Quiz

