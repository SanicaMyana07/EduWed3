"use client"

import IssueReporter from "../src/components/IssueReporter"

export default function SyntheticV0PageForDeployment() {
  return <IssueReporter />
}