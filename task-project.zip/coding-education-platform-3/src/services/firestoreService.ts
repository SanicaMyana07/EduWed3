import { firestore } from "../firebase"
import firebase from "firebase/compat/app" // Import firebase

export const getUserData = async (userId) => {
  const userDoc = await firestore.collection("users").doc(userId).get()
  return userDoc.data()
}

export const getQuizzes = async () => {
  const quizzesSnapshot = await firestore.collection("quizzes").get()
  return quizzesSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
}

export const getCourseResources = async () => {
  const resourcesSnapshot = await firestore.collection("resources").get()
  return resourcesSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
}

export const getPosts = async () => {
  const postsSnapshot = await firestore.collection("posts").orderBy("createdAt", "desc").get()
  return postsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
}

export const createPost = async (postData) => {
  const newPost = await firestore.collection("posts").add({
    ...postData,
    createdAt: new Date(),
  })
  return { id: newPost.id, ...postData }
}

export const addComment = async (postId, commentData) => {
  const postRef = firestore.collection("posts").doc(postId)
  await postRef.update({
    comments: firebase.firestore.FieldValue.arrayUnion(commentData),
  })
  const updatedPost = await postRef.get()
  return { id: updatedPost.id, ...updatedPost.data() }
}

export const getEvents = async () => {
  const eventsSnapshot = await firestore.collection("events").get()
  return eventsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
}

export const getUserQuestionHistory = async (userId) => {
  const historySnapshot = await firestore.collection("userQuestionHistory").doc(userId).get()
  return historySnapshot.data() || {}
}

